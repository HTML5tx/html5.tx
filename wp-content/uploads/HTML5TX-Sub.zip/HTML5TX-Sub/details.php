<div id="detailsWrap">
	<div id="detailsLeft">
		<div class="sectionTitle">
			<span class="st1">DETAILS:</span><span class="st2">Should you attend? Hellz yeah. Here's why.</span>
		</div>

		<p class="detailText">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		<p class="detailText">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>

		<div id="whenWhere">
			<table id="whenGrid">
				<tbody>
					<tr id="wgRow1">
						<td id="wgTitle">When, Where & Cost</td>
						<td></td>
						<td></td>
					</tr>
					<tr id="wgRow2">
						<td>Saturday
						<p id="dateHL">October 8, 2011</p></td>
						<td>St. Edwards University, Ragsdale Center</td>
						<td></td>
					</tr>
					<tr id="wgRow3">
						<td><p id="timeHL">8am to 5pm</p>
						With some extra-curricular activities (likely the day before and after) to be announced closer to the event.</td>
						<td></td>
						<td><p id="priceHL">$79.00</p>
						<a href="#">Go register already.</a></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>

	<div id="detailsRight">
		<div class="topLink"><a href="#top">BACK TO TOP</a></div>
		<div id="theTweets">
			<h2><a href="http://twitter.com/html5tx" target="_blank">Follow: html5tx</a></h2>
			<?php twitter_messages("html5tx", 4, true, true, "#", true, true, false); ?>
		</div>
		<div id="socialLinks">
			<p>Share:</p><a href="http://twitter.com/html5tx" target="_blank"><img src="wp-content/themes/HTML5TX/images/twitterLink.png"></a><a href="http://www.facebook.com/pages/HTML5tx/240781395942312" target="_blank"><img src="wp-content/themes/HTML5TX/images/facebookLink.png"></a>
		</div>
	</div>
</div>