		<div id="footer">
			<p>&copy;<?php echo date("Y"); echo " "; bloginfo('name'); ?>.  All Rights Reserved.</p>
		</div>

	</div>

	<?php wp_footer(); ?>
	
</body>

</html>
