<?php get_header(); ?>
<div id="mainContent">

	<h2>Error 404 - Page Not Found</h2>

</div>
	
<?php get_sidebar(); ?>

<?php get_footer(); ?>