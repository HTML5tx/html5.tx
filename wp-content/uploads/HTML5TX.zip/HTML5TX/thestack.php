<?php include '/wp-content/themes/HTML5TX/details.php'; ?>

<?php include '/wp-content/themes/HTML5TX/register.php'; ?>